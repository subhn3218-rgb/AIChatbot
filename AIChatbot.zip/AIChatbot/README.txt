ARIA - Java AI Chatbot (Rule-Based NLP + Swing GUI)
=====================================================
This is now a FULL NetBeans project (has an nbproject/ folder), so it
opens directly with File > Open Project - no wizard steps needed.

PROJECT STRUCTURE
------------------
AIChatbot/
  nbproject/
    project.xml            -> NetBeans project metadata
    project.properties     -> NetBeans build settings (main class, etc.)
  build.xml                -> Imports NetBeans' auto-generated build-impl.xml
  manifest.mf              -> JAR manifest
  src/chatbot/
    Main.java               -> Application entry point (run this)
    ChatbotGUI.java          -> Swing GUI (chat window)
    ChatbotEngine.java       -> Matching logic (keyword/overlap similarity)
    KnowledgeBase.java       -> Stores FAQ rules, loads data/faqs.txt
    NLPProcessor.java        -> Tokenizing, stop-word removal, stemming
  data/
    faqs.txt                 -> Editable FAQ "training" data (see below)
    unanswered.txt            -> Auto-created; logs unmatched questions

HOW TO OPEN IN NETBEANS (should just work)
---------------------------------------------
1. Unzip this project anywhere on disk.
2. Open NetBeans.
3. File > Open Project...
4. Browse to and select the "AIChatbot" folder itself (the one containing
   nbproject/, src/, data/, build.xml) -> click Open Project.
5. NetBeans will recognize it as a Java SE project and automatically
   generate its internal nbproject/build-impl.xml the first time you open
   or build it (this is normal NetBeans behavior - it's a private,
   auto-generated file, so it's fine that it wasn't included).
6. In the Projects panel, expand Source Packages > chatbot, right-click
   Main.java > Run File (or select the project and press F6 to Run Project).

If NetBeans still doesn't recognize the folder as a project (e.g. very old
NetBeans versions with a different project schema), use the fallback
method instead:
   File > New Project > Java with Ant > Java Application
   -> uncheck "Create Main Class" -> Finish
   -> then copy the contents of src/chatbot/ into the new project's
      src/chatbot folder, and copy the data/ folder into the new
      project's root folder (same level as build.xml).

HOW TO RUN WITHOUT NETBEANS (command line / any OS)
------------------------------------------------------
  cd AIChatbot
  javac -d build/classes src/chatbot/*.java
  java -cp build/classes chatbot.Main

(Run java from inside the AIChatbot folder so the relative path
data/faqs.txt resolves correctly.)

HOW THE CHATBOT WORKS
-----------------------
1. NLPProcessor cleans and tokenizes user input, removes stop-words
   (including question words like "how", "why"), and applies light
   stemming (e.g. "running" -> "run").
2. KnowledgeBase holds a list of FAQ entries (keyword-set -> response),
   loaded from data/faqs.txt at startup.
3. ChatbotEngine compares the user's extracted keywords against every
   FAQ entry's keywords using an overlap coefficient (intersection size
   divided by the smaller set's size -- this works well even when the
   user types a short message like "hello" against a longer FAQ pattern).
   The highest-scoring response above a confidence threshold is returned.
   Below that threshold, a randomized fallback message is returned and
   the question is logged to data/unanswered.txt.
4. ChatbotGUI is a Swing JFrame with a scrollable, timestamped chat
   history (right-aligned blue bubbles for you, left-aligned white
   bubbles for ARIA), a text field, and a Send button (Enter also works).

"TRAINING" THE BOT ON NEW FAQs
--------------------------------
Open data/faqs.txt and add a new line in this format:

    trigger keywords or example question|||The response to give.

Save the file and restart the app -- no recompiling needed. Check
data/unanswered.txt periodically to see what real users are asking that
the bot didn't recognize, and turn those into new FAQ lines.

EXTENDING THIS PROJECT
------------------------
- Swap the keyword-overlap matcher in ChatbotEngine for a real ML model
  (e.g. call an HTTP API, or integrate a Java ML library) if you want
  statistical/ML-based intent classification instead of rules.
- Add multi-turn context by storing the last N exchanges in ChatbotEngine
  and factoring them into scoring.
- Swap the Swing GUI for a web interface by wrapping ChatbotEngine in a
  small servlet / Spring Boot REST endpoint and building an HTML/JS
  front-end that calls it via fetch().
