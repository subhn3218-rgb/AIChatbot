package chatbot;

import java.io.*;
import java.util.*;

public class KnowledgeBase {
    public static class FAQEntry {
        final Set<String> keywords;
        final String response;
        final String rawPattern;
        
        FAQEntry(Set<String> keywords, String response, String rawPattern) {
            this.keywords = keywords;
            this.response = response;
            this.rawPattern = rawPattern;
        }
    }
    
    private final List<FAQEntry> entries = new ArrayList<>();
    private final NLPProcessor nlp;
    private static final String FAQ_FILE_PATH = "data/faqs.txt";
    
    public KnowledgeBase(NLPProcessor nlp) {
        this.nlp = nlp;
        loadFAQs();
    }
    
    public void addFAQ(String patternLine, String response) {
        Set<String> kws = nlp.extractKeywords(patternLine);
        if (!kws.isEmpty()) {
            entries.add(new FAQEntry(kws, response, patternLine));
        }
    }
    
    // YEH NAYA FUNCTION HAI JO BOT KO TRAIN KAREGA
    public void trainNewFAQ(String question, String answer) {
        addFAQ(question, answer); // Add to memory
        try { // Save to file automatically
            File dir = new File("data");
            if (!dir.exists()) dir.mkdirs();
            try (FileWriter fw = new FileWriter(FAQ_FILE_PATH, true)) {
                fw.write(System.lineSeparator() + question + "|||" + answer);
            }
        } catch (IOException e) {
            System.err.println("Failed to save training data: " + e.getMessage());
        }
    }
    
    private void loadFAQs() {
        loadDefaults();
        File f = new File(FAQ_FILE_PATH);
        if (f.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    String[] parts = line.split("\\|\\|\\|");
                    if (parts.length == 2) {
                        addFAQ(parts[0].trim(), parts[1].trim());
                    }
                }
            } catch (IOException e) {
                System.err.println("Could not read " + FAQ_FILE_PATH + ": " + e.getMessage());
            }
        }
    }
    
    private void loadDefaults() {
        addFAQ("hello hi hey greetings good morning good evening", "Hello there! I am ready to answer your Computer Science and Programming questions.");
        addFAQ("can you help me in programming code coding", "Yes! I can help you with Java, OOP concepts, algorithms, and general Computer Science topics.");
        addFAQ("what is java programming language", "Java is a high-level, class-based, object-oriented programming language.");
        addFAQ("what is oops object oriented programming", "OOP stands for Object-Oriented Programming. Its 4 main pillars are: Inheritance, Polymorphism, Abstraction, and Encapsulation.");
    }
    
    public List<FAQEntry> getEntries() {
        return entries;
    }
}