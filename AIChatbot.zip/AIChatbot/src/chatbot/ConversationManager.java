package chatbot;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ConversationManager {
    private static final String HISTORY_DIR = "data/history/";
    private final List<Conversation> conversations;

    public ConversationManager() {
        this.conversations = new ArrayList<>();
        File dir = new File(HISTORY_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        loadAll();
    }

    private void loadAll() {
        File dir = new File(HISTORY_DIR);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".chat"));
        if (files != null) {
            for (File file : files) {
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                    Conversation conv = (Conversation) ois.readObject();
                    conversations.add(conv);
                } catch (Exception e) {
                    System.err.println("Error loading conversation " + file.getName() + ": " + e.getMessage());
                }
            }
        }
        conversations.sort((a, b) -> Long.compare(b.getCreatedAt(), a.getCreatedAt()));
    }

    public List<Conversation> getConversations() {
        return conversations;
    }

    public void save(Conversation conv) {
        if (!conversations.contains(conv)) {
            conversations.add(0, conv);
        }
        try {
            File dir = new File(HISTORY_DIR);
            if (!dir.exists()) dir.mkdirs();
            
            File file = new File(dir, conv.getId() + ".chat");
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                oos.writeObject(conv);
            }
        } catch (IOException e) {
            System.err.println("Failed to save conversation: " + e.getMessage());
        }
    }
}