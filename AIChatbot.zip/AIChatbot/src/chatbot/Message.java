package chatbot;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Message implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private final String sender;
    private final String text;
    private final long timestamp;
    private final boolean isUser;
    private final boolean isImage;

    public Message(String sender, String text, boolean isUser, boolean isImage) {
        this.sender = sender;
        this.text = text;
        this.timestamp = System.currentTimeMillis();
        this.isUser = isUser;
        this.isImage = isImage;
    }

    public String getSender() { return sender; }
    public String getText() { return text; }
    public long getTimestamp() { return timestamp; }
    public boolean isUser() { return isUser; }
    public boolean isImage() { return isImage; }

    public String getFormattedTime() {
        return new SimpleDateFormat("HH:mm").format(new Date(timestamp));
    }
}