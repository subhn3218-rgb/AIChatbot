package chatbot;

import java.io.*;
import java.util.*;

public class ChatbotEngine {
    private final NLPProcessor nlp;
    private final KnowledgeBase kb;
    private final Random random = new Random();

    private static final double MATCH_THRESHOLD = 0.34;
    public static final int FREE_LIMIT = 15;

    private static final String[] FALLBACKS = {
            "I'm not fully sure I understand. Could you rephrase that?",
            "That's outside what I currently know. Try training me!",
            "I haven't learned the answer to that yet. Click 'Train Bot' to teach me."
    };

    public ChatbotEngine() {
        this.nlp = new NLPProcessor();
        this.kb = new KnowledgeBase(nlp);
    }
    
    // YEH NAYA FUNCTION HAI
    public void trainBot(String question, String answer) {
        kb.trainNewFAQ(question, answer);
    }

    public String getResponse(String userInput, Conversation conversation) {
        if (conversation.getUserMessageCount() >= FREE_LIMIT) {
            return "[PREMIUM REQUIRED] You have reached the free limit of " + FREE_LIMIT + " messages. Please upgrade to continue chatting.";
        }
        if (userInput == null || userInput.trim().isEmpty()) {
            return "Please type something!";
        }
        Set<String> inputKeywords = nlp.extractKeywords(userInput);
        if (inputKeywords.isEmpty()) {
            return "I didn't quite catch that.";
        }

        KnowledgeBase.FAQEntry best = null;
        double bestScore = 0;

        for (KnowledgeBase.FAQEntry entry : kb.getEntries()) {
            double score = overlapCoefficient(inputKeywords, entry.keywords);
            if (score > bestScore) {
                bestScore = score;
                best = entry;
            }
        }
        if (best != null && bestScore >= MATCH_THRESHOLD) {
            return best.response;
        }
        logUnanswered(userInput);
        return FALLBACKS[random.nextInt(FALLBACKS.length)];
    }

    private double overlapCoefficient(Set<String> a, Set<String> b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        Set<String> intersection = new HashSet<>(a);
        intersection.retainAll(b);
        int smaller = Math.min(a.size(), b.size());
        return (double) intersection.size() / smaller;
    }

    private void logUnanswered(String input) {
        try {
            File dir = new File("data");
            if (!dir.exists()) dir.mkdirs();
            try (FileWriter fw = new FileWriter("data/unanswered.txt", true)) {
                fw.write(input + System.lineSeparator());
            }
        } catch (IOException ignored) {}
    }
}