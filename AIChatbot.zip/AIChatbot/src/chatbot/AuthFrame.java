package chatbot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;
import javax.imageio.ImageIO;

public class AuthFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel cardPanel;

    // Professional High-Contrast Colors
    private static final Color TEXT_LIGHT = new Color(255, 255, 255);
    private static final Color TEXT_MUTED = new Color(200, 200, 210);
    private static final Color ACCENT_BLUE = new Color(10, 132, 255);
    private static final Color ACCENT_HOVER = new Color(0, 110, 230);
    
    private static final Color FIELD_BG = new Color(255, 255, 255, 240); 
    private static final Color FIELD_TEXT = new Color(30, 30, 30);

    // Database File to permanently save created accounts
    private static final String DB_FILE = "user_credentials.properties";
    private static Properties userDatabase = new Properties();

    // Load saved accounts when the program starts
    static {
        try {
            File f = new File(DB_FILE);
            if (f.exists()) {
                userDatabase.load(new FileInputStream(f));
            } else {
                // Add a default test account if the file doesn't exist yet
                userDatabase.setProperty("test@email.com", "test_123");
            }
        } catch (Exception e) {
            System.err.println("Could not load user database.");
        }
    }

    public AuthFrame() {
        setTitle("ARIA Pro - Welcome");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Open full screen
        setResizable(true);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.setOpaque(false); // No background box, completely transparent

        cardPanel.add(buildLoginPanel(), "LOGIN");
        cardPanel.add(buildSignUpPanel(), "SIGNUP");

        BackgroundImagePanel bgPanel = new BackgroundImagePanel("C:\\Users\\User\\Downloads\\steve-a-johnson-ZPOoDQc8yMw-unsplash.jpg");
        bgPanel.setLayout(new GridBagLayout()); 
        bgPanel.add(cardPanel);

        add(bgPanel);
    }

    private JPanel buildLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false); 
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Heading
        JLabel titleLabel = new JLabel("Welcome Back");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 34)); 
        titleLabel.setForeground(TEXT_LIGHT);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 15, 5, 15);
        panel.add(titleLabel, gbc);

        // Subtitle
        JLabel subtitleLabel = new JLabel("Log in to your ARIA Pro account");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14)); 
        subtitleLabel.setForeground(TEXT_MUTED);
        gbc.gridy = 1; 
        gbc.insets = new Insets(0, 15, 35, 15);
        panel.add(subtitleLabel, gbc);

        gbc.gridwidth = 1;

        // Email Row
        JLabel emailLabel = createFormLabel("Email:");
        JTextField emailField = createTextField();
        gbc.gridy = 2; gbc.gridx = 0; gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(8, 15, 8, 15);
        panel.add(emailLabel, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panel.add(emailField, gbc);

        // Password Row 
        JLabel passLabel = createFormLabel("Password:");
        JPasswordField passField = new JPasswordField(); 
        JPanel passWrapper = createPasswordPanel(passField); 
        gbc.gridy = 3; gbc.gridx = 0; gbc.anchor = GridBagConstraints.EAST;
        panel.add(passLabel, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panel.add(passWrapper, gbc);

        // Login Button
        JButton loginBtn = new JButton("Log In");
        styleAuthButton(loginBtn);
        loginBtn.addActionListener(e -> {
            String email = emailField.getText().trim();
            String password = new String(passField.getPassword());
            
            // 1. Check if fields are empty
            if (email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields to log in.", "Empty Fields Error", JOptionPane.WARNING_MESSAGE);
            } 
            else {
                // 2. Fetch the password for this email from our permanent file database
                String savedPassword = userDatabase.getProperty(email);
                
                if (savedPassword == null || !savedPassword.equals(password)) {
                    JOptionPane.showMessageDialog(this, "Incorrect email or password entered.\nPlease check your details and try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                } 
                // 3. Successful Login
                else {
                    JOptionPane.showMessageDialog(this, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    SwingUtilities.invokeLater(() -> new ChatbotGUI().setVisible(true));
                }
            }
        });
        gbc.gridy = 4; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(25, 15, 15, 15);
        panel.add(loginBtn, gbc);

        // Switch link
        JPanel switchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        switchPanel.setOpaque(false);
        JLabel noAccountLabel = new JLabel("Don't have an account?");
        noAccountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        noAccountLabel.setForeground(TEXT_MUTED);
        
        JLabel signUpLink = new JLabel("Sign up");
        signUpLink.setFont(new Font("Segoe UI", Font.BOLD, 14));
        signUpLink.setForeground(ACCENT_BLUE);
        signUpLink.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signUpLink.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { 
                emailField.setText("");
                passField.setText("");
                cardLayout.show(cardPanel, "SIGNUP"); 
            }
            @Override public void mouseEntered(MouseEvent e) { signUpLink.setForeground(ACCENT_HOVER); }
            @Override public void mouseExited(MouseEvent e) { signUpLink.setForeground(ACCENT_BLUE); }
        });
        switchPanel.add(noAccountLabel);
        switchPanel.add(signUpLink);

        gbc.gridy = 5; 
        gbc.insets = new Insets(5, 15, 15, 15);
        panel.add(switchPanel, gbc);

        return panel;
    }

    private JPanel buildSignUpPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false); 
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Heading
        JLabel titleLabel = new JLabel("Create Account");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 34)); 
        titleLabel.setForeground(TEXT_LIGHT);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 15, 5, 15);
        panel.add(titleLabel, gbc);

        // Subtitle
        JLabel subtitleLabel = new JLabel("Get started with your free plan");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14)); 
        subtitleLabel.setForeground(TEXT_MUTED);
        gbc.gridy = 1; 
        gbc.insets = new Insets(0, 15, 30, 15);
        panel.add(subtitleLabel, gbc);

        gbc.gridwidth = 1;

        // Full Name Row
        JLabel nameLabel = createFormLabel("Full Name:");
        JTextField nameField = createTextField();
        gbc.gridy = 2; gbc.gridx = 0; gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(8, 15, 8, 15);
        panel.add(nameLabel, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panel.add(nameField, gbc);

        // Email Row
        JLabel emailLabel = createFormLabel("Email:");
        JTextField emailField = createTextField();
        gbc.gridy = 3; gbc.gridx = 0; gbc.anchor = GridBagConstraints.EAST;
        panel.add(emailLabel, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panel.add(emailField, gbc);

        // Password Row 
        JLabel passLabel = createFormLabel("Password:");
        JPasswordField passField = new JPasswordField(); 
        JPanel passWrapper = createPasswordPanel(passField); 
        gbc.gridy = 4; gbc.gridx = 0; gbc.anchor = GridBagConstraints.EAST;
        panel.add(passLabel, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panel.add(passWrapper, gbc);

        // Sign Up Button
        JButton signUpBtn = new JButton("Sign Up");
        styleAuthButton(signUpBtn);
        signUpBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String password = new String(passField.getPassword());

            // 1. Check if fields are empty
            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields to create an account.", "Empty Fields Error", JOptionPane.WARNING_MESSAGE);
            } 
            // 2. Validate Password Rules
            else if (!isValidPassword(password)) {
                JOptionPane.showMessageDialog(this, 
                    "Invalid Password!\n\nYour password must:\n- Not exceed 8 characters\n- Contain at least one letter\n- Contain an underscore (_)", 
                    "Password Security Error", 
                    JOptionPane.ERROR_MESSAGE);
            } 
            // 3. Successful Sign Up - SAVE TO FILE PERMANENTLY
            else {
                userDatabase.setProperty(email, password); // Add to properties
                try {
                    // Save to the actual physical file
                    userDatabase.store(new FileOutputStream(DB_FILE), "ARIA Pro User Accounts");
                } catch (Exception ex) {
                    System.err.println("Failed to save user account to file.");
                }

                JOptionPane.showMessageDialog(this, "Account created successfully! You can now log in.", "Success", JOptionPane.INFORMATION_MESSAGE);
                
                nameField.setText("");
                emailField.setText("");
                passField.setText("");
                cardLayout.show(cardPanel, "LOGIN");
            }
        });
        gbc.gridy = 5; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(25, 15, 15, 15);
        panel.add(signUpBtn, gbc);

        // Switch link
        JPanel switchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        switchPanel.setOpaque(false);
        JLabel haveAccountLabel = new JLabel("Already have an account?");
        haveAccountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        haveAccountLabel.setForeground(TEXT_MUTED);
        
        JLabel loginLink = new JLabel("Log in");
        loginLink.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginLink.setForeground(ACCENT_BLUE);
        loginLink.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginLink.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { cardLayout.show(cardPanel, "LOGIN"); }
            @Override public void mouseEntered(MouseEvent e) { loginLink.setForeground(ACCENT_HOVER); }
            @Override public void mouseExited(MouseEvent e) { loginLink.setForeground(ACCENT_BLUE); }
        });
        switchPanel.add(haveAccountLabel);
        switchPanel.add(loginLink);

        gbc.gridy = 6;
        gbc.insets = new Insets(5, 15, 15, 15);
        panel.add(switchPanel, gbc);

        return panel;
    }

    // --- Validation Helper ---
    private boolean isValidPassword(String password) {
        if (password.length() > 8) {
            return false;
        }
        boolean hasLetter = false;
        boolean hasUnderscore = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isLetter(c)) hasLetter = true;
            if (c == '_') hasUnderscore = true;
        }
        
        return hasLetter && hasUnderscore;
    }

    // --- GUI Helper Styling Utilities ---

    private JLabel createFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 18)); 
        label.setForeground(TEXT_LIGHT);
        return label;
    }

    private JTextField createTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15)); 
        field.setBackground(FIELD_BG); 
        field.setForeground(FIELD_TEXT); 
        field.setCaretColor(FIELD_TEXT);
        field.setPreferredSize(new Dimension(280, 40)); 
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true), 
                BorderFactory.createEmptyBorder(0, 10, 0, 10)
        ));
        return field;
    }

    // Helper to wrap password field and attach an Eye toggle button flush with it
    private JPanel createPasswordPanel(JPasswordField passField) {
        JPanel wrapper = new JPanel(new BorderLayout(0, 0));
        wrapper.setOpaque(false);
        
        passField.setFont(new Font("Segoe UI", Font.PLAIN, 15)); 
        passField.setBackground(FIELD_BG);
        passField.setForeground(FIELD_TEXT);
        passField.setCaretColor(FIELD_TEXT);
        
        passField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 1, 1, 0, new Color(200, 200, 200)), 
                BorderFactory.createEmptyBorder(0, 10, 0, 10)
        ));
        
        JToggleButton eyeBtn = new JToggleButton("👁");
        eyeBtn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16)); 
        eyeBtn.setForeground(new Color(120, 120, 120)); 
        eyeBtn.setBackground(FIELD_BG); 
        
        eyeBtn.setOpaque(true);
        eyeBtn.setContentAreaFilled(true);
        eyeBtn.setFocusPainted(false);
        eyeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        eyeBtn.setPreferredSize(new Dimension(45, 40));
        
        eyeBtn.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(200, 200, 200)));
        
        eyeBtn.addActionListener(e -> {
            if (eyeBtn.isSelected()) {
                passField.setEchoChar((char) 0); 
                eyeBtn.setForeground(ACCENT_BLUE); 
            } else {
                passField.setEchoChar('•'); 
                eyeBtn.setForeground(new Color(120, 120, 120)); 
            }
        });

        wrapper.add(passField, BorderLayout.CENTER);
        wrapper.add(eyeBtn, BorderLayout.EAST);
        
        return wrapper;
    }

    private void styleAuthButton(JButton button) {
        button.setBackground(ACCENT_BLUE);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16)); 
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(200, 45)); 
        
        button.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { button.setBackground(ACCENT_HOVER); }
            @Override public void mouseExited(MouseEvent e) { button.setBackground(ACCENT_BLUE); }
        });
    }

    private static class BackgroundImagePanel extends JPanel {
        private Image backgroundImage;

        public BackgroundImagePanel(String filePath) {
            try {
                backgroundImage = ImageIO.read(new File(filePath));
            } catch (Exception e) {
                System.err.println("Background image load failed.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                Graphics2D g2d = (Graphics2D) g.create();

                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int panelW = getWidth();
                int panelH = getHeight();
                int imgW = backgroundImage.getWidth(this);
                int imgH = backgroundImage.getHeight(this);

                if (imgW > 0 && imgH > 0) {
                    double scale = Math.max((double) panelW / imgW, (double) panelH / imgH);
                    int drawW = (int) Math.ceil(imgW * scale);
                    int drawH = (int) Math.ceil(imgH * scale);
                    int x = (panelW - drawW) / 2;
                    int y = (panelH - drawH) / 2;
                    g2d.drawImage(backgroundImage, x, y, drawW, drawH, this);
                } else {
                    g2d.drawImage(backgroundImage, 0, 0, panelW, panelH, this);
                }
                
                g2d.setColor(new Color(0, 0, 0, 160)); 
                g2d.fillRect(0, 0, panelW, panelH);

                g2d.dispose();
            } else {
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(
                        0, 0, new Color(10, 10, 15),
                        0, getHeight(), new Color(20, 25, 30)
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AuthFrame().setVisible(true));
    }
}