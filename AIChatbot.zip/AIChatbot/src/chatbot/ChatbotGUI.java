package chatbot;

import javax.swing.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ChatbotGUI extends JFrame {
    private final ChatbotEngine engine;
    private final ConversationManager convManager;
    private Conversation currentConversation;

    private JPanel chatContainer;
    private JTextField inputField;
    private JButton sendButton;
    private JButton attachButton;
    private JLabel statusLabel;
    private JPanel sidebarPanel;
    private DefaultListModel<Conversation> historyListModel;
    private JList<Conversation> historyList;

    // ---- Premium design tokens ----
    private static final Color BG_COLOR = new Color(248, 249, 251);      // App / chat background
    private static final Color BOT_BUBBLE = new Color(255, 255, 255);    // Bot bubble fill
    private static final Color USER_BUBBLE = new Color(10, 132, 255);    // Brand accent (also used as accent throughout)
    private static final Color HEADER_COLOR = new Color(24, 24, 27);     // Near-black header
    private static final Color SIDEBAR_COLOR = new Color(24, 24, 27);    // Near-black sidebar
    private static final Color ACTION_BLACK = new Color(20, 20, 20);     // Primary action buttons
    private static final Color BORDER_LIGHT = new Color(228, 228, 231);  // Hairline borders on light bg
    private static final Color TEXT_MUTED = new Color(140, 140, 148);    // Secondary text on light bg
    private static final Color SIDEBAR_TEXT_MUTED = new Color(150, 150, 155);

    private static final String FONT_FAMILY = "Segoe UI";

    /**
     * Lightens (amount > 0) or darkens (amount < 0) a color by a proportion 0..1.
     * Used to derive hover/pressed states from a single base color instead of
     * hardcoding extra palette entries everywhere.
     */
    private static Color shade(Color base, double amount) {
        int r = base.getRed(), g = base.getGreen(), b = base.getBlue();
        if (amount >= 0) {
            r = (int) Math.round(r + (255 - r) * amount);
            g = (int) Math.round(g + (255 - g) * amount);
            b = (int) Math.round(b + (255 - b) * amount);
        } else {
            r = (int) Math.round(r * (1 + amount));
            g = (int) Math.round(g * (1 + amount));
            b = (int) Math.round(b * (1 + amount));
        }
        r = Math.max(0, Math.min(255, r));
        g = Math.max(0, Math.min(255, g));
        b = Math.max(0, Math.min(255, b));
        return new Color(r, g, b);
    }

    public ChatbotGUI() {
        this.engine = new ChatbotEngine();
        this.convManager = new ConversationManager();
        initComponents();
        startNewConversation();
    }

    private void initComponents() {
        setTitle("ARIA Pro - AI Chatbot Assistant");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setMinimumSize(new Dimension(760, 560));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(buildSidebar(), BorderLayout.WEST);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(buildHeaderPanel(), BorderLayout.NORTH);
        mainPanel.add(buildChatPanel(), BorderLayout.CENTER);
        mainPanel.add(buildInputPanel(), BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (currentConversation != null && !currentConversation.getMessages().isEmpty()) {
                    convManager.save(currentConversation);
                }
            }
        });
    }

    // ==================================================================
    //  SIDEBAR
    // ==================================================================

    private JPanel buildSidebar() {
        sidebarPanel = new JPanel(new BorderLayout());
        sidebarPanel.setBackground(SIDEBAR_COLOR);
        sidebarPanel.setPreferredSize(new Dimension(268, 0));

        JPanel topButtonsPanel = new JPanel(new GridLayout(2, 1, 0, 10));
        topButtonsPanel.setBackground(SIDEBAR_COLOR);
        topButtonsPanel.setBorder(BorderFactory.createEmptyBorder(18, 16, 18, 16));

        RoundedButton newChatBtn = new RoundedButton("+   New Chat", Color.WHITE, new Color(20, 20, 20), 10);
        newChatBtn.setFont(new Font(FONT_FAMILY, Font.BOLD, 14));
        newChatBtn.addActionListener(e -> startNewConversation());

        RoundedButton trainBtn = new RoundedButton("\u2699   Train Bot", new Color(52, 53, 65), Color.WHITE, 10);
        trainBtn.setFont(new Font(FONT_FAMILY, Font.BOLD, 14));
        trainBtn.addActionListener(e -> {
            String question = JOptionPane.showInputDialog(this, "Enter the Question you want the bot to learn:");
            if (question != null && !question.trim().isEmpty()) {
                String answer = JOptionPane.showInputDialog(this, "Enter the Answer for this question:");
                if (answer != null && !answer.trim().isEmpty()) {
                    engine.trainBot(question, answer);
                    JOptionPane.showMessageDialog(this, "Bot successfully trained! Try asking the question now.");
                }
            }
        });

        topButtonsPanel.add(newChatBtn);
        topButtonsPanel.add(trainBtn);
        sidebarPanel.add(topButtonsPanel, BorderLayout.NORTH);

        JPanel historyContainer = new JPanel(new BorderLayout());
        historyContainer.setBackground(SIDEBAR_COLOR);

        JLabel historyLabel = new JLabel("  CONVERSATION HISTORY");
        historyLabel.setForeground(new Color(110, 110, 118));
        historyLabel.setFont(new Font(FONT_FAMILY, Font.BOLD, 11));
        historyLabel.setBorder(BorderFactory.createEmptyBorder(8, 8, 10, 8));
        historyContainer.add(historyLabel, BorderLayout.NORTH);

        historyListModel = new DefaultListModel<>();
        for (Conversation c : convManager.getConversations()) {
            historyListModel.addElement(c);
        }

        historyList = new JList<>(historyListModel);
        historyList.setBackground(SIDEBAR_COLOR);
        historyList.setCursor(new Cursor(Cursor.HAND_CURSOR));
        historyList.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        historyList.setFixedCellHeight(-1);

        historyList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                            boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                Conversation conv = (Conversation) value;
                label.setText(" " + conv.getTitle());
                label.setIcon(new BubbleIcon(15, isSelected ? Color.WHITE : new Color(150, 150, 158)));
                label.setIconTextGap(10);
                label.setFont(new Font(FONT_FAMILY, Font.PLAIN, 13));
                if (isSelected) {
                    label.setBackground(new Color(45, 45, 52));
                    label.setForeground(Color.WHITE);
                    label.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createMatteBorder(0, 3, 0, 0, USER_BUBBLE),
                            BorderFactory.createEmptyBorder(12, 10, 12, 13)));
                } else {
                    label.setBackground(SIDEBAR_COLOR);
                    label.setForeground(new Color(200, 200, 205));
                    label.setBorder(BorderFactory.createEmptyBorder(12, 13, 12, 13));
                }
                return label;
            }
        });

        historyList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && historyList.getSelectedValue() != null) {
                loadConversation(historyList.getSelectedValue());
            }
        });

        JScrollPane scroll = new JScrollPane(historyList);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(SIDEBAR_COLOR);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        scroll.getVerticalScrollBar().setUI(new BlackScrollBarUI(new Color(0, 0, 0), SIDEBAR_COLOR));
        historyContainer.add(scroll, BorderLayout.CENTER);

        sidebarPanel.add(historyContainer, BorderLayout.CENTER);
        sidebarPanel.add(buildAccountPanel(), BorderLayout.SOUTH);

        return sidebarPanel;
    }

    private JPanel buildAccountPanel() {
        JPanel accountPanel = new JPanel(new BorderLayout(12, 0));
        accountPanel.setBackground(SIDEBAR_COLOR);
        accountPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(48, 48, 52)),
                BorderFactory.createEmptyBorder(12, 14, 14, 14)));
        accountPanel.setCursor(new Cursor(Cursor.HAND_CURSOR));

        AvatarCircle avatar = new AvatarCircle("G", new Color(90, 90, 98), Color.WHITE, 32);

        JPanel textBox = new JPanel(new GridLayout(2, 1));
        textBox.setBackground(SIDEBAR_COLOR);
        JLabel nameLabel = new JLabel("My Account");
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setFont(new Font(FONT_FAMILY, Font.BOLD, 13));
        JLabel planLabel = new JLabel("Free Plan");
        planLabel.setForeground(SIDEBAR_TEXT_MUTED);
        planLabel.setFont(new Font(FONT_FAMILY, Font.PLAIN, 11));
        textBox.add(nameLabel);
        textBox.add(planLabel);

        JLabel moreIcon = new JLabel("\u22EF");
        moreIcon.setForeground(new Color(180, 180, 180));
        moreIcon.setFont(new Font(FONT_FAMILY, Font.BOLD, 16));

        accountPanel.add(avatar, BorderLayout.WEST);
        accountPanel.add(textBox, BorderLayout.CENTER);
        accountPanel.add(moreIcon, BorderLayout.EAST);

        JPopupMenu accountMenu = new JPopupMenu();
        JMenuItem upgradeItem = new JMenuItem("\u2B06\uFE0F  Upgrade Plan");
        upgradeItem.addActionListener(e -> showUpgradeDialog());
        JMenuItem settingsItem = new JMenuItem("\u2699\uFE0F  Settings");
        settingsItem.addActionListener(e -> showSettingsDialog());
        JMenuItem signOutItem = new JMenuItem("\uD83D\uDEAA  Sign Out");
        signOutItem.addActionListener(e -> handleSignOut());
        accountMenu.add(upgradeItem);
        accountMenu.add(settingsItem);
        accountMenu.addSeparator();
        accountMenu.add(signOutItem);

        MouseAdapter openMenu = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                accountMenu.show(accountPanel, e.getX(), e.getY() - accountMenu.getPreferredSize().height - 5);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                Color hover = shade(SIDEBAR_COLOR, 0.10);
                accountPanel.setBackground(hover);
                textBox.setBackground(hover);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                accountPanel.setBackground(SIDEBAR_COLOR);
                textBox.setBackground(SIDEBAR_COLOR);
            }
        };
        accountPanel.addMouseListener(openMenu);
        avatar.addMouseListener(openMenu);
        textBox.addMouseListener(openMenu);
        moreIcon.addMouseListener(openMenu);

        return accountPanel;
    }

    private void showSettingsDialog() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 8));
        panel.add(new JLabel("Account: guest@ariapro.ai"));
        panel.add(new JLabel("Plan: Free Plan"));
        panel.add(new JLabel("Theme: Light"));
        JOptionPane.showMessageDialog(this, panel, "Settings", JOptionPane.PLAIN_MESSAGE);
    }

    private void handleSignOut() {
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to sign out?",
                "Sign Out", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            if (currentConversation != null && !currentConversation.getMessages().isEmpty()) {
                convManager.save(currentConversation);
            }
            JOptionPane.showMessageDialog(this, "You have been signed out.");
            dispose();
            System.exit(0);
        }
    }

    private void showUpgradeDialog() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 1, 0, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel heading = new JLabel("Upgrade ARIA Pro");
        heading.setFont(new Font(FONT_FAMILY, Font.BOLD, 16));
        panel.add(heading);

        panel.add(new JLabel("Free — $0/mo — Basic responses, limited history"));
        panel.add(new JLabel("Plus — $12/mo — Faster replies, file uploads, priority support"));
        panel.add(new JLabel("Pro — $25/mo — Unlimited training, advanced memory, early features"));

        JOptionPane.showMessageDialog(this, panel, "Upgrade Plan", JOptionPane.PLAIN_MESSAGE);
    }

    // ==================================================================
    //  HEADER
    // ==================================================================

    private JPanel buildHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(HEADER_COLOR);
        header.setBorder(BorderFactory.createEmptyBorder(16, 24, 16, 24));

        JPanel titleBox = new JPanel();
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        titleBox.setOpaque(false);
        JLabel title = new JLabel("ARIA Pro");
        title.setForeground(Color.WHITE);
        title.setFont(new Font(FONT_FAMILY, Font.BOLD, 19));
        JLabel subtitle = new JLabel("Your personal AI assistant");
        subtitle.setForeground(SIDEBAR_TEXT_MUTED);
        subtitle.setFont(new Font(FONT_FAMILY, Font.PLAIN, 12));
        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(2));
        titleBox.add(subtitle);

        statusLabel = new JLabel("\u25CF  Online");
        statusLabel.setForeground(new Color(94, 224, 130));
        statusLabel.setFont(new Font(FONT_FAMILY, Font.BOLD, 12));

        RoundedPanel statusBadge = new RoundedPanel(20, new Color(255, 255, 255, 18));
        statusBadge.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
        statusBadge.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        statusBadge.add(statusLabel);

        RoundedButton upgradeBtn = new RoundedButton("\u26A1  Upgrade", new Color(255, 196, 12), new Color(30, 30, 30), 20);
        upgradeBtn.setFont(new Font(FONT_FAMILY, Font.BOLD, 13));
        upgradeBtn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        upgradeBtn.addActionListener(e -> showUpgradeDialog());

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(statusBadge);
        rightPanel.add(upgradeBtn);

        header.add(titleBox, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    // ==================================================================
    //  CHAT AREA
    // ==================================================================

    private JScrollPane buildChatPanel() {
        chatContainer = new JPanel();
        chatContainer.setLayout(new BoxLayout(chatContainer, BoxLayout.Y_AXIS));
        chatContainer.setBackground(BG_COLOR);
        chatContainer.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JScrollPane scrollPane = new JScrollPane(chatContainer);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(BG_COLOR);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0));
        scrollPane.getVerticalScrollBar().setUI(new BlackScrollBarUI(new Color(0, 0, 0), BG_COLOR));
        return scrollPane;
    }

    private JPanel createMessageRow(Message msg) {
        boolean isUser = msg.isUser();

        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createEmptyBorder(4, 24, 4, 24));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        AvatarCircle avatar = isUser
                ? new AvatarCircle("U", new Color(90, 90, 98), Color.WHITE, 30)
                : new AvatarCircle("A", USER_BUBBLE, Color.WHITE, 30);

        JPanel bubble = buildBubble(msg, isUser);

        if (isUser) {
            row.add(Box.createHorizontalGlue());
            row.add(bubble);
            row.add(Box.createHorizontalStrut(10));
            row.add(avatar);
        } else {
            row.add(avatar);
            row.add(Box.createHorizontalStrut(10));
            row.add(bubble);
            row.add(Box.createHorizontalGlue());
        }

        // Without this, the row has no max height, so the parent's Y_AXIS
        // BoxLayout stretches it (and the bubble inside it) to fill any
        // leftover vertical space in the scroll viewport, producing a huge
        // near-empty box for a one-line message.
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, row.getPreferredSize().height));
        return row;
    }

    private JPanel buildBubble(Message msg, boolean isUser) {
        Color bg = isUser ? USER_BUBBLE : BOT_BUBBLE;
        Color fg = isUser ? Color.WHITE : new Color(30, 32, 40);
        Color borderColor = isUser ? null : BORDER_LIGHT;

        RoundedPanel bubble = new RoundedPanel(16, bg, borderColor, borderColor != null ? 1 : 0);
        bubble.setLayout(new BoxLayout(bubble, BoxLayout.Y_AXIS));
        bubble.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

        JLabel meta = new JLabel(msg.getSender() + "   \u00B7   " + msg.getFormattedTime());
        meta.setFont(new Font(FONT_FAMILY, Font.BOLD, 11));
        meta.setForeground(isUser ? new Color(255, 255, 255, 190) : TEXT_MUTED);
        meta.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextArea body = new JTextArea(msg.getText());
        body.setEditable(false);
        body.setLineWrap(true);
        body.setWrapStyleWord(true);
        body.setOpaque(false);
        body.setFont(new Font(FONT_FAMILY, msg.isImage() ? Font.ITALIC : Font.PLAIN, 14));
        body.setForeground(fg);
        body.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));
        body.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.setFocusable(false);

        int maxWidth = 320;
        body.setSize(new Dimension(maxWidth, Short.MAX_VALUE));
        Dimension pref = body.getPreferredSize();
        int width = Math.min(maxWidth, Math.max(pref.width, 60));
        body.setPreferredSize(new Dimension(width, pref.height));
        body.setMaximumSize(new Dimension(width, Integer.MAX_VALUE));

        bubble.add(meta);
        bubble.add(body);
        bubble.setMaximumSize(new Dimension(maxWidth + 40, Integer.MAX_VALUE));
        bubble.setAlignmentX(isUser ? Component.RIGHT_ALIGNMENT : Component.LEFT_ALIGNMENT);

        return bubble;
    }

    // ==================================================================
    //  INPUT BAR
    // ==================================================================

    private JPanel buildInputPanel() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(Color.WHITE);
        outer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_LIGHT),
                BorderFactory.createEmptyBorder(16, 24, 20, 24)
        ));

        RoundedPanel pill = new RoundedPanel(26, new Color(244, 245, 247), BORDER_LIGHT, 1);
        pill.setLayout(new BorderLayout(8, 0));
        pill.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));

        attachButton = new RoundedButton("", new Color(244, 245, 247), new Color(90, 90, 95), 18);
        attachButton.setIcon(new AttachIcon(18, new Color(90, 90, 95)));
        attachButton.setToolTipText("Upload Text File");
        attachButton.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        attachButton.addActionListener(e -> handleFileUpload());

        inputField = new PlaceholderTextField("Message ARIA...");
        inputField.setFont(new Font(FONT_FAMILY, Font.PLAIN, 15));
        inputField.setOpaque(false);
        inputField.setBorder(BorderFactory.createEmptyBorder(10, 6, 10, 6));
        inputField.addActionListener(e -> handleSend());

        sendButton = new RoundedButton("Send", ACTION_BLACK, Color.WHITE, 20);
        sendButton.setFont(new Font(FONT_FAMILY, Font.BOLD, 14));
        sendButton.setIcon(new SendIcon(11, Color.WHITE));
        sendButton.setIconTextGap(8);
        sendButton.setHorizontalTextPosition(SwingConstants.RIGHT);
        sendButton.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        sendButton.addActionListener(e -> handleSend());

        pill.add(attachButton, BorderLayout.WEST);
        pill.add(inputField, BorderLayout.CENTER);
        pill.add(sendButton, BorderLayout.EAST);

        // Pill now stretches the full width of the input area instead of being
        // capped/centered, so it spans edge-to-edge like a standard message bar.
        outer.add(pill, BorderLayout.CENTER);
        return outer;
    }

    // ==================================================================
    //  CONVERSATION LOGIC (unchanged behavior, adapted to new chat panel)
    // ==================================================================

    private void startNewConversation() {
        if (currentConversation != null && !currentConversation.getMessages().isEmpty()) {
            convManager.save(currentConversation);
            if (!historyListModel.contains(currentConversation)) {
                historyListModel.add(0, currentConversation);
            }
        }
        currentConversation = new Conversation();
        clearChatView();
        historyList.clearSelection();

        Message botGreeting = new Message("ARIA", "Hi! I'm ARIA Pro. Ask me anything or click 'Train Bot' to teach me something new!", false, false);
        currentConversation.addMessage(botGreeting);
        renderMessage(botGreeting);
    }

    private void loadConversation(Conversation conv) {
        if (currentConversation != null && !currentConversation.getMessages().isEmpty() && currentConversation != conv) {
            convManager.save(currentConversation);
        }
        currentConversation = conv;
        clearChatView();
        for (Message msg : conv.getMessages()) {
            renderMessage(msg);
        }
    }

    private void clearChatView() {
        chatContainer.removeAll();
        chatContainer.revalidate();
        chatContainer.repaint();
    }

    private void handleFileUpload() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Text Files (.txt)", "txt"));
        int returnVal = chooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            sendMessage("You", "[File Attached: " + file.getName() + "]", true, true);

            if (file.getName().toLowerCase().endsWith(".txt")) {
                try {
                    String content = new String(java.nio.file.Files.readAllBytes(file.toPath()));
                    Timer timer = new Timer(150, e -> {
                        String response = engine.getResponse(content, currentConversation);
                        sendMessage("ARIA", response, false, false);
                    });
                    timer.setRepeats(false);
                    timer.start();
                } catch (Exception ex) {
                    Timer timer = new Timer(150, e -> {
                        sendMessage("ARIA", "Sorry, file read karne mein koi error aagaya.", false, false);
                    });
                    timer.setRepeats(false);
                    timer.start();
                }
            } else {
                Timer timer = new Timer(150, e -> {
                    sendMessage("ARIA", "Main abhi sirf .txt files (Notepad files) read kar sakti hoon! PDF ya Images read karne ke liye extra libraries chahiye.", false, false);
                });
                timer.setRepeats(false);
                timer.start();
            }
        }
    }

    private void handleSend() {
        String text = inputField.getText().trim();
        if (text.isEmpty()) return;
        inputField.setText("");
        sendMessage("You", text, true, false);
        inputField.setEnabled(false);
        sendButton.setEnabled(false);
        statusLabel.setText("\u25CF  Typing...");
        statusLabel.setForeground(new Color(240, 180, 60));

        Timer timer = new Timer(150, e -> {
            try {
                String response = engine.getResponse(text, currentConversation);
                sendMessage("ARIA", response, false, false);
            } catch (Exception ex) {
                System.err.println("Error generating response: " + ex.getMessage());
                sendMessage("ARIA", "Sorry, I ran into an error processing that. Could you try rephrasing?", false, false);
            } finally {
                inputField.setEnabled(true);
                sendButton.setEnabled(true);
                statusLabel.setText("\u25CF  Online");
                statusLabel.setForeground(new Color(94, 224, 130));
                inputField.requestFocusInWindow();
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    private void sendMessage(String sender, String text, boolean isUser, boolean isImage) {
        Message msg = new Message(sender, text, isUser, isImage);
        currentConversation.addMessage(msg);
        renderMessage(msg);

        if (isUser) {
            historyList.repaint();
        }
    }

    private void renderMessage(Message msg) {
        JPanel row = createMessageRow(msg);
        chatContainer.add(row);
        chatContainer.add(Box.createVerticalStrut(2));
        chatContainer.revalidate();
        chatContainer.repaint();
        scrollChatToBottom();
    }

    private void scrollChatToBottom() {
        SwingUtilities.invokeLater(() -> {
            Container viewport = chatContainer.getParent();
            if (viewport instanceof JViewport) {
                Container scroll = viewport.getParent();
                if (scroll instanceof JScrollPane) {
                    JScrollBar vBar = ((JScrollPane) scroll).getVerticalScrollBar();
                    vBar.setValue(vBar.getMaximum());
                }
            }
        });
    }

    // ==================================================================
    //  CUSTOM PREMIUM UI COMPONENTS
    // ==================================================================

    /** Flat rounded-rect button with hover/pressed shading derived from a single base color. */
    private static class RoundedButton extends JButton {
        private final Color baseColor;
        private final int radius;
        private boolean hovering = false;
        private boolean pressing = false;

        RoundedButton(String text, Color baseColor, Color textColor, int radius) {
            super(text);
            this.baseColor = baseColor;
            this.radius = radius;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(textColor);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFont(new Font(FONT_FAMILY, Font.BOLD, 13));
            setHorizontalAlignment(SwingConstants.CENTER);
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    pressing = true;
                    repaint();
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    pressing = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color fill = baseColor;
            if (!isEnabled()) {
                fill = shade(baseColor, -0.15);
            } else if (pressing) {
                fill = shade(baseColor, -0.12);
            } else if (hovering) {
                fill = shade(baseColor, 0.12);
            }
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Rounded-rect panel with optional 1px hairline border, used for cards, badges and the input pill. */
    private static class RoundedPanel extends JPanel {
        private final int radius;
        private final Color bgColor;
        private final Color borderColor;
        private final int borderWidth;

        RoundedPanel(int radius, Color bgColor) {
            this(radius, bgColor, null, 0);
        }

        RoundedPanel(int radius, Color bgColor, Color borderColor, int borderWidth) {
            this.radius = radius;
            this.bgColor = bgColor;
            this.borderColor = borderColor;
            this.borderWidth = borderWidth;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bgColor);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            if (borderColor != null && borderWidth > 0) {
                g2.setColor(borderColor);
                g2.setStroke(new BasicStroke(borderWidth));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Small circular avatar with a single-letter initial, used next to chat bubbles and the account row. */
    private static class AvatarCircle extends JComponent {
        private final String initial;
        private final Color bg;
        private final Color fg;
        private final int size;

        AvatarCircle(String initial, Color bg, Color fg, int size) {
            this.initial = initial;
            this.bg = bg;
            this.fg = fg;
            this.size = size;
            setPreferredSize(new Dimension(size, size));
            setMinimumSize(new Dimension(size, size));
            setMaximumSize(new Dimension(size, size));
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bg);
            g2.fillOval(0, 0, size, size);
            g2.setColor(fg);
            g2.setFont(new Font(FONT_FAMILY, Font.BOLD, size / 2));
            FontMetrics fm = g2.getFontMetrics();
            int tx = (size - fm.stringWidth(initial)) / 2;
            int ty = (size - fm.getHeight()) / 2 + fm.getAscent();
            g2.drawString(initial, tx, ty);
            g2.dispose();
        }
    }

    /**
     * Slim black scrollbar with rounded thumb and no arrow buttons.
     * Plain setBackground() on a JScrollBar is ignored by most Look and Feels,
     * so the only reliable way to recolor one is to replace its UI delegate.
     */
    private static class BlackScrollBarUI extends BasicScrollBarUI {
        private final Color thumbColor;
        private final Color trackColor;

        BlackScrollBarUI(Color thumbColor, Color trackColor) {
            this.thumbColor = thumbColor;
            this.trackColor = trackColor;
        }

        @Override
        protected JButton createDecreaseButton(int orientation) {
            return zeroSizeButton();
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            return zeroSizeButton();
        }

        private JButton zeroSizeButton() {
            JButton button = new JButton();
            button.setPreferredSize(new Dimension(0, 0));
            button.setMinimumSize(new Dimension(0, 0));
            button.setMaximumSize(new Dimension(0, 0));
            return button;
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(trackColor);
            g2.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);
            g2.dispose();
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
            if (thumbBounds.isEmpty() || !c.isEnabled()) return;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int pad = 2;
            int arc = 8;
            g2.setColor(thumbColor);
            g2.fillRoundRect(
                    thumbBounds.x + pad,
                    thumbBounds.y + pad,
                    Math.max(0, thumbBounds.width - pad * 2),
                    Math.max(0, thumbBounds.height - pad * 2),
                    arc, arc
            );
            g2.dispose();
        }
    }

    /** Small speech-bubble icon, drawn with vector shapes so it renders identically on every system font. */
    private static class BubbleIcon implements Icon {
        private final int size;
        private final Color color;

        BubbleIcon(int size, Color color) {
            this.size = size;
            this.color = color;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            int w = size;
            int h = (int) (size * 0.72);
            g2.fillRoundRect(x, y, w, h, 5, 5);
            int[] xs = {x + 4, x + 4, x + 10};
            int[] ys = {y + h - 1, y + h + 4, y + h - 1};
            g2.fillPolygon(xs, ys, 3);
            g2.dispose();
        }

        @Override
        public int getIconWidth() {
            return size;
        }

        @Override
        public int getIconHeight() {
            return size;
        }
    }

    /** Simple attach/clip icon drawn as a rotated rounded loop, avoiding emoji font fallback issues. */
    private static class AttachIcon implements Icon {
        private final int size;
        private final Color color;

        AttachIcon(int size, Color color) {
            this.size = size;
            this.color = color;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.translate(x + size / 2.0, y + size / 2.0);
            g2.rotate(Math.toRadians(45));
            int w = (int) (size * 0.34);
            int h = (int) (size * 0.8);
            g2.drawRoundRect(-w / 2, -h / 2, w, h, w, w);
            g2.dispose();
        }

        @Override
        public int getIconWidth() {
            return size;
        }

        @Override
        public int getIconHeight() {
            return size;
        }
    }

    /** Right-pointing triangle "send" icon. */
    private static class SendIcon implements Icon {
        private final int size;
        private final Color color;

        SendIcon(int size, Color color) {
            this.size = size;
            this.color = color;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            int[] xs = {x, x, x + size};
            int[] ys = {y, y + size, y + size / 2};
            g2.fillPolygon(xs, ys, 3);
            g2.dispose();
        }

        @Override
        public int getIconWidth() {
            return size;
        }

        @Override
        public int getIconHeight() {
            return size;
        }
    }

    /**
     * Centers a single child component and caps its width at maxWidth, shrinking the
     * child below that cap if the wrapper itself becomes narrower (e.g. minimized window).
     * Used to keep the message input pill the same width as a chat bubble instead of
     * stretching it edge-to-edge.
     */
    private static class CenteredCapPanel extends JPanel {
        private final Component content;
        private final int maxWidth;

        CenteredCapPanel(Component content, int maxWidth) {
            this.content = content;
            this.maxWidth = maxWidth;
            setOpaque(false);
            setLayout(null);
            add(content);
        }

        @Override
        public void doLayout() {
            int w = Math.min(maxWidth, getWidth());
            int h = getHeight();
            int x = (getWidth() - w) / 2;
            content.setBounds(x, 0, w, h);
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension contentPref = content.getPreferredSize();
            return new Dimension(maxWidth, contentPref.height);
        }
    }

    /** Text field that shows light placeholder text when empty and unfocused (native Swing has no such option). */
    private static class PlaceholderTextField extends JTextField {
        private final String placeholder;
        private final Color placeholderColor = new Color(160, 160, 165);

        PlaceholderTextField(String placeholder) {
            this.placeholder = placeholder;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getText().isEmpty() && !isFocusOwner()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(placeholderColor);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = getInsets().left;
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(placeholder, x, y);
                g2.dispose();
            }
        }
    }
}