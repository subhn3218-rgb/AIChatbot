package chatbot;
import java.util.*;
public class NLPProcessor {
    // Common English & Roman English stop-words
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            // English
            "a", "an", "the", "is", "are", "was", "were", "am", "i", "you", "he", "she",
            "it", "we", "they", "to", "of", "in", "on", "for", "and", "or", "but", "do",
            "does", "did", "can", "could", "would", "will", "shall", "should", "my", "your",
            "his", "her", "its", "our", "their", "this", "that", "these", "those", "what",
            "which", "who", "whom", "me", "us", "them", "be", "been", "being", "with",
            "at", "by", "from", "as", "if", "then", "so", "just", "please",
            "how", "why", "when", "where", "tell", "give", "let", "know", "about",
            
            // Roman English
            "hai", "h", "ho", "tha", "thi", "mera", "meri", "tum", "aap", "woh", "ye", "yeh",
            "ki", "ka", "ke", "ko", "se", "aur", "ya", "par", "mein", "liye", "bhi"
    ));
    public String normalize(String text) {
        if (text == null) return "";
        String cleaned = text.toLowerCase().replaceAll("[^a-z0-9\\s]", " ");
        return cleaned.trim().replaceAll("\\s+", " ");
    }
    public List<String> tokenize(String text) {
        String normalized = normalize(text);
        if (normalized.isEmpty()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(normalized.split(" ")));
    }
    public List<String> removeStopWords(List<String> tokens) {
        List<String> result = new ArrayList<>();
        for (String t : tokens) {
            if (!STOP_WORDS.contains(t)) {
                result.add(t);
            }
        }
        return result;
    }
    public String stem(String word) {
        if (word.length() > 5 && word.endsWith("ing")) return word.substring(0, word.length() - 3);
        if (word.length() > 6 && word.endsWith("edly")) return word.substring(0, word.length() - 4);
        if (word.length() > 4 && word.endsWith("ed")) return word.substring(0, word.length() - 2);
        if (word.length() > 5 && word.endsWith("ies")) return word.substring(0, word.length() - 3) + "y";
        if (word.length() > 4 && word.endsWith("es")) return word.substring(0, word.length() - 2);
        if (word.length() > 3 && word.endsWith("s") && !word.endsWith("ss")) return word.substring(0, word.length() - 1);
        return word;
    }
    public Set<String> extractKeywords(String text) {
        List<String> tokens = removeStopWords(tokenize(text));
        Set<String> keywords = new LinkedHashSet<>();
        for (String t : tokens) {
            keywords.add(stem(t));
        }
        return keywords;
    }
}
