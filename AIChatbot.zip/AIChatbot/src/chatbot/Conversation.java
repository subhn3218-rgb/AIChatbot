package chatbot;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
public class Conversation implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private final String id;
    private String title;
    private final List<Message> messages;
    private final long createdAt;
    
    private int userMessageCount = 0;
    public Conversation() {
        this.id = UUID.randomUUID().toString();
        this.title = "New Chat";
        this.messages = new ArrayList<>();
        this.createdAt = System.currentTimeMillis();
    }
    public String getId() { return id; }
    public String getTitle() { return title; }
    public List<Message> getMessages() { return messages; }
    public long getCreatedAt() { return createdAt; }
    public int getUserMessageCount() { return userMessageCount; }
    public void addMessage(Message msg) {
        // Agar yeh user ka pehla text message hai, toh isko Topic Name (Title) bana dein
        if (msg.isUser() && this.title.equals("New Chat") && !msg.isImage()) {
            String text = msg.getText();
            this.title = text.length() > 25 ? text.substring(0, 25) + "..." : text;
        }
        if (msg.isUser()) {
            userMessageCount++;
        }
        messages.add(msg);
    }
    
    @Override
    public String toString() {
        return title;
    }

    public void setTitle(String topic) {
        if (topic == null || topic.trim().isEmpty()) {
            return;
        }
        this.title = topic.trim();
    }
}